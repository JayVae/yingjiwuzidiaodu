package com.risk.plan.service.box.warehouse;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.WareHouse;
@Service
public class WareHouseService extends BaseService<WareHouse>{

}
