package com.risk.plan.service.box.transport;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.TransLive;

@Service
public class TransliveService extends BaseService<TransLive>{

}
