package com.risk.plan.service.box.scheme;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.Scheme;

@Service
public class SchemeService extends BaseService<Scheme>{
   
}
