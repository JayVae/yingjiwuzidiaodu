package com.risk.plan.service.box.users;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.Roles;
@Service
public class RolesService extends BaseService<Roles> {

}
