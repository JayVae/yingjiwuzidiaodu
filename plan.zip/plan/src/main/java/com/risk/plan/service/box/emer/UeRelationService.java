package com.risk.plan.service.box.emer;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.UERelation;
@Service
public class UeRelationService extends BaseService<UERelation> {

}
