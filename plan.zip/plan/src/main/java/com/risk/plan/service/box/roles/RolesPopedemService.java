package com.risk.plan.service.box.roles;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.RolePopedem;
@Service
public class RolesPopedemService extends BaseService<RolePopedem> {

}
