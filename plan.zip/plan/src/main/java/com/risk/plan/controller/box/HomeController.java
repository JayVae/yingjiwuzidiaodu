package com.risk.plan.controller.box;

import org.springframework.stereotype.Controller;

@Controller
public class HomeController {
		/*
		private ModelMap modelmap;*/
		
		
}
