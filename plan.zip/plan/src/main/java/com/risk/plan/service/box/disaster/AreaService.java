package com.risk.plan.service.box.disaster;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.Area;
@Service	
public class AreaService extends BaseService<Area> {

}
