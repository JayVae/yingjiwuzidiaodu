package com.risk.plan.service.box.goods;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.Goods;
/** 
* @ClassName: GoodsService 
* @Description: TODO
* @author yjw 10291095_xjtu_edu_com 
* @date 2015年10月4日 下午9:50:22 
*  
*/
@Service	
public class GoodsService extends BaseService<Goods> {
	
	
}
