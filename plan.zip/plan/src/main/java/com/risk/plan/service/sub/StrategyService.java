package com.risk.plan.service.sub;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.Strategy;

@Service
public class StrategyService extends BaseService<Strategy>{

}
