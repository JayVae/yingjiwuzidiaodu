package com.risk.plan.service.box.transport;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.TranModel;

@Service
public class TranmodelService extends BaseService<TranModel>{

}
