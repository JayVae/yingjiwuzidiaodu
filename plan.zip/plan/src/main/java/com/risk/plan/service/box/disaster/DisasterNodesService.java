package com.risk.plan.service.box.disaster;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.DisasterNode;
@Service
public class DisasterNodesService extends BaseService<DisasterNode> {

}
