package com.risk.plan.dao;


import com.risk.plan.common.BaseMapper;
import com.risk.plan.common.MyBatisRepository;
import com.risk.plan.entity.Gene;
@MyBatisRepository
public interface GeneMapper extends BaseMapper<Gene>{
}