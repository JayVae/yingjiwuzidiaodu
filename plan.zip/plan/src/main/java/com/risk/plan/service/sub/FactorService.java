package com.risk.plan.service.sub;

import org.springframework.stereotype.Service;

import com.risk.plan.common.BaseService;
import com.risk.plan.entity.Factor;

@Service
public class FactorService extends BaseService<Factor>{

}
